function myFuncttion(xml){
    var i;
}